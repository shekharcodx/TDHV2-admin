import React from "react";


import SettingC from "../../components/SettingC/SettingC";


const Setting = () => {
    return (
        <div>

            <SettingC />
        </div>
    );
};

export default Setting;