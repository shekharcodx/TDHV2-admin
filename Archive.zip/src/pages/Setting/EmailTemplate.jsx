import React from "react";

import EmailTemplateForm from "../../components/EmailTemplate/EmailTemplateFormC";


const EmailTemplate = () => {
    return (
        <div>
            <EmailTemplateForm />
        </div>
    );
};

export default EmailTemplate;