import React from "react";

import CarSettingsForm from "../../components/SettingC/CarSetting/CarSettingsForm";
import Carform from "../../components/SettingC/CarSetting/Carform";

const Setting = () => {
    return (
        <div>
            <Carform />
            <CarSettingsForm />
            
            </div>
    );
};

export default Setting;