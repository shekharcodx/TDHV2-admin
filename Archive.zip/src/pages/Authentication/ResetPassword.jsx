"use client";

import React, { useState } from "react";
import styles from "./ResetPassword.module.css";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { toast } from "sonner"; // ✅ or "react-hot-toast" depending on what you're using

const ResetPassword = () => {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const location = useLocation();
  const navigate = useNavigate();

  // ✅ Extract token from query params (?token=abc123)
  const queryParams = new URLSearchParams(location.search);
  const token = queryParams.get("token");

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Basic validation
    if (password !== confirmPassword) {
      toast.error("Passwords do not match!");
      return;
    }
    if (!token) {
      toast.error("Invalid or missing token.");
      return;
    }

    // ✅ API call wrapped in toast.promise
    toast.promise(
      fetch(`${import.meta.env.VITE_API_URL}/resetPassword`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: token,
          newPassword: password,
        }),
      }).then(async (res) => {
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.message || "Something went wrong");
        }
        return data; // pass to success handler
      }),
      {
        loading: {
          title: "Resetting Password...",
          description: "Please wait while we update your password.",
        },
        success: (result) => {
          // On success → redirect
          setTimeout(() => navigate("/sign-in"), 2000);
          return {
            title: result?.message || "Password reset successful!",
            description: "Redirecting to sign in...",
          };
        },
        error: (error) => {
          return {
            title: error.message || "Reset Failed",
            description: "Please try again later",
          };
        },
      }
    );
  };

  return (
    <div className={styles.ResetPasswordWrapper}>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-6 col-lg-4">
            <div className={`card p-4 shadow ${styles.resetCard}`}>
              <h3 className="text-center mb-4">Reset Password</h3>

              <form onSubmit={handleSubmit}>
                {/* New Password */}
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">
                    New Password
                  </label>
                  <input
                    type="password"
                    id="password"
                    className={`form-control ${styles.inputField}`}
                    placeholder="Enter new password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>

                {/* Confirm Password */}
                <div className="mb-3">
                  <label htmlFor="confirmPassword" className="form-label">
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    id="confirmPassword"
                    className={`form-control ${styles.inputField}`}
                    placeholder="Confirm new password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </div>

                {/* Submit Button */}
                <button type="submit" className={`w-100 ${styles.submitBtn}`}>
                  Reset Password
                </button>

                <div className="d-flex justify-content-between mt-4">
                  <h6 className="mt-2 text-center">OR</h6>
                  <Link to="/sign-in" className={styles.forgetLink}>
                    Sign In
                  </Link>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
