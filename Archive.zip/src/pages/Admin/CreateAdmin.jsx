import React from "react";
import CreateAdminComponent from "../../components/AdminComponent/CreateAdminComponent";    

const CreateAdmin =()=>{
    return(
        <>
        <CreateAdminComponent/>
        
        </>
    )
}

export default CreateAdmin;