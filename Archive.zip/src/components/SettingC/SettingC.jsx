import React from "react";
import AddCity from "./Locations/AddLocations";

const SettingC = () => {
    return (
        <div>
            
            <AddCity />
            </div>
    );
};

export default SettingC;